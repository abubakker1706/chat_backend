export const jwtSecret = "jwt-secret";
